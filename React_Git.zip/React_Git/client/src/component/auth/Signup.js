import React from 'react';
import {Field,reduxForm}from 'redux-form';
import {connect}  from 'react-redux';
import {compose} from 'redux';
import  *as actions from '../../actions'
class Signup extends React.Component{
    onSubmit =(formData)=>
    {
        console.log(formData);
         // here give action to reduser

    }
    render(){
  const {handleSubmit}=this.props;
        return (
            <div>
                <form onSubmit={handleSubmit(this.onSubmit)}>
                    <fieldset>
                        <label>Email</label>
                        <Field name="email" component="input" type="text" />
                    </fieldset>
                    <fieldset>
                        <label>Password</label>
                        <Field name="password" component="input" type="password" />
                    </fieldset>
                    <button>Sign Up</button>
                </form>
            </div>
        )
    }
}

export default compose(connect(null,actions),reduxForm({form:'Signup'}) (Signup)) //accept any no of heigher fun
//export default connect()()reduxForm({form:'Signup'}) (Signup);