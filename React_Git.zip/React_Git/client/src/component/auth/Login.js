import React from 'react';

const Login = () => {
    return (
        <div>
            This is Login page
        </div>
    );
}

export default Login;
