import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
    return (
        <div>
          <Link to="/products">Products</Link> &nbsp;&nbsp;&nbsp;
          <Link to="/categories">Categories</Link>  &nbsp;&nbsp;&nbsp;
          <Link to="/logout">Logout</Link>   &nbsp;&nbsp;&nbsp;
          <Link to="/signup">SignUp</Link>  
        </div>
    );
};


export default Header;
