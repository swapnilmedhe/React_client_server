import React from 'react';

import Header from './Header';

// const App = (props) => {
//   return (
//     <div>
//      <Header/>
//       { props.children }
//     </div>
//   );
// }

const App = ({children}) => {
  return (
    <div>
     <Header/>
      {children }
    </div>
  );
};

export default App;
