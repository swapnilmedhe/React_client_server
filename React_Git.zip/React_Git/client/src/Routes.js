import React, { Fragment } from 'react';
import { Route} from 'react-router-dom';
import Login from './component/auth/Login';
import Signup from './component/auth/Signup';

const Routes = () => {
    return (
        <Fragment>
            <Route path = "/" exact component = {Login} />
            <Route path = "/signup" exact component = {Signup} />
            
        </Fragment>
    );
}

export default Routes;


