
const INITIAL_STATE=
{
   authenticated:'',
   errorMessage:''
}
export default (state=INITIAL_STATE,action)=>
{
    //base on action return state
    return state;
}