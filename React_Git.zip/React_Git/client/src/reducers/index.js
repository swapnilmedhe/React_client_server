import{combineReducers} from 'redux';
import authReducer from './authReducers';
import {reducer as fromReduser}  from 'redux-form';

export default combineReducers({
    auth:authReducer,
    form:fromReduser
})