import React from 'react';
import ReactDOM from 'react-dom';
import App from './component/App';
import { BrowserRouter as Router} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Routes from './Routes';
import{Provider} from 'react-redux';
import  configuresTORE from './store';


const store =configuresTORE();
ReactDOM.render(
    <Provider store={store}>        
   <Router>
        <App> 
            <Routes />
        </App>
   </Router>
   </Provider>,
    document.getElementById('root')






    
 );
