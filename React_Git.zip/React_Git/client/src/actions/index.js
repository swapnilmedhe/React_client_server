import axios from 'axios';

import {AUTH_USER,AUTH_ERROR} from './types';

export const signUp=(formData)=> async dispach=>{
    try{

        const response =await axios.post('http://localhost:4090/singUp',formData)
        console.log();
        dispach({type:'AUTH_USER'});
    } catch(ex)
    {
        dispach({type:'AUTH_ERROR', payload:'an error occures'})
    }
    
  
}

    //dispach 
 
