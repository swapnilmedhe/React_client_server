const Product = require('../models/product');

exports.getProducts = function(req, res,next){
  var filter = req.query.category ? { category: req.query.category } : {};
  Product.find(filter, function(err, products){
    if(err){
      return next(err);
    }
    if(products.length === 0 ){
      return res.status(404).send({
        error: 'No products found in this category'
      });
    }
    return res.status(200).send(products);
  })
}

exports.getProductById = function(req, res, next){
  Product.findOne({
    _id: req.params.id
  }, function(err, existingProduct){
    if(err){
      return next(err);
    }
    if(existingProduct){
      return res.status(200).send(existingProduct);
    }
    if(!existingProduct){
      return res.status(404).send({
        error: 'No product found'
      });
    }
  })
}

exports.saveProduct = function(req, res, next) {
  const product = req.body;
  Product.findOne({
    name: product.name
  }, function(err, existingProduct){
    if(err){
      return next(err);
    }
    if(existingProduct){
      return res.status(422).send({
        error: 'Duplicate Product Name'
      });
    }
    const newProduct = new Product({
      name: product.name,
      category: product.category,
      description: product.description,
      price: product.price
    });

    newProduct.save(function(err){
      if(err) {
        return next(err);
      }
      res.json(newProduct);
    })
  })
}

exports.deleteProduct = function(req, res, next){
  Product.findOne({
    _id: req.params.id
  }, function(err, existingProduct){
    if(err){
      return next(err);
    }
    if(!existingProduct){
      return res.status(404).send({
        error: 'No product found'
      });
    }
    if(existingProduct){
      Product.deleteOne({_id: req.params.id}, function(err){
        if(err){
          return next(err);
        }
        return res.status(204).send();
      })
      
    }
    
  })
}