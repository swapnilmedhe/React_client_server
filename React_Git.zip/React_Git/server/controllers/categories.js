const Category = require('../models/category');

exports.getCategories = function (req, res, next) {
  Category.find({}, function (err, categories) {
    if (err) {
      return next(err);
    }
    if (categories.length === 0) {
      return res.status(404).send({
        error: 'No Categories Found'
      });
    }
    return res.status(200).send(categories);
  })
}

exports.getCategoryById = function (req, res, next) {
  Category.findOne({
    _id: req.params.id
  }, function (err, existingCategory) {
    if (err) {
      return next(err);
    }
    if (existingCategory) {
      return res.status(200).send(existingCategory);
    }
    if (!existingCategory) {
      return res.status(404).send({
        error: 'No Category found'
      });
    }
  })
}

exports.saveCategory = function (req, res, next) {
  const category = req.body;
  Category.findOne({
    name: category.name
  }, function (err, existingCategory) {
    if (err) {
      return next(err);
    }
    if (existingCategory) {
      return res.status(422).send({
        error: 'Duplicate Category Name'
      });
    }
    const newCategory = new Category({
      name: category.name,
      description: category.description
    });

    newCategory.save(function (err) {
      if (err) {
        return next(err);
      }
      res.json(newCategory);
    })
  })
}

exports.deleteCategory = function (req, res, next) {
  Category.findOne({
    _id: req.params.id
  }, function (err, existingCategory) {
    if (err) {
      return next(err);
    }
    if (!existingCategory) {
      return res.status(404).send({
        error: 'No category found'
      });
    }
    if (existingCategory) {
      Category.deleteOne({ _id: req.params.id }, function (err) {
        if (err) {
          return next(err);
        }
        return res.status(204).send();
      })

    }

  })
}