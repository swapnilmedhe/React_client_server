const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const categorySchema = new Schema({
  name: {
    type: String,
    required: true,
    minlength: 3,
    maxlength: 20
  },
  description: {
    type: String,
    required: true,
    minlength: 10,
    maxlength: 50
  }
});

const ModelClass = mongoose.model('category', categorySchema);

//export the model

module.exports = ModelClass;