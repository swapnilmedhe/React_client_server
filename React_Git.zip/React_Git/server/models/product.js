const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const productSchema = new Schema({
  name: {
    type: String,
    unique: true,
    minlength: 5,
    maxlength: 50
  },
  category: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true,
    minlength:5,
    maxlength: 100
  },
  price: {
    type: Number,
    required: true
  }
});

const ModelClass = mongoose.model('product', productSchema);

//export the model

module.exports = ModelClass;