const express = require('express');
const app = express();
const http = require('http');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const router = require('./router');
const mongoose = require('mongoose');
const cors = require('cors');

require('dotenv').config();

//DB Setup

const dbURI =
  "mongodb://mongouser:C0mplexP%40ss@cluster0-shard-00-00-zcsfc.mongodb.net:27017,cluster0-shard-00-01-zcsfc.mongodb.net:27017,cluster0-shard-00-02-zcsfc.mongodb.net:27017/Shopping?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin";
const options = {
  reconnectTries: Number.MAX_VALUE,
  poolSize: 10
};

mongoose.connect(dbURI, options).then(() => {
  console.log("Connected to database!");
}).catch(err => {
  console.log("Error while connecting to database", err);
});
//App setup
app.use(morgan('combined'));

//cors configuration
var whitelist = ['http://localhost', 'http://127.0.0.1', 'http://vilasd-lap'];
var corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) != -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  }
}

app.use(cors({
  corsOptions
}));


app.use(bodyParser.json({
  type: '*/*'
}));
router(app);

//Server Setup
const port = process.env.PORT || 3090;
const server = http.createServer(app);
server.listen(port);
console.log(`Server listening on ${port}`);