const Authentication = require('./controllers/authentication');
const Products = require('./controllers/products');
const Categories = require('./controllers/categories');
const passportService = require('./services/passport');
const passport = require('passport');

const requireAuth = passport.authenticate('jwt', {
  session: false
});

const requireSignin = passport.authenticate('local', {
  session: false
});


module.exports = function (app) {
  app.get('/', requireAuth, function (req, res) {
    res.send({
      hi: 'there'
    });
  });
  app.post('/signin', requireSignin, Authentication.signin);
  app.post('/signup', Authentication.signup);
  app.post('/products', requireAuth, Products.saveProduct);
  app.get('/products/:id', requireAuth, Products.getProductById);
  app.get('/products', requireAuth,Products.getProducts);
  app.delete('/products/:id', requireAuth, Products.deleteProduct);
  app.post('/categories', requireAuth, Categories.saveCategory);
  app.get('/categories/:id', requireAuth, Categories.getCategoryById);
  app.get('/categories', requireAuth,Categories.getCategories);
  app.delete('/categories/:id', requireAuth, Categories.deleteCategory);
}